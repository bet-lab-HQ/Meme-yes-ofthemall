
# Meme Coin Project

## 🚀 Latest Deployments (Sepolia)

```json
[]
```
